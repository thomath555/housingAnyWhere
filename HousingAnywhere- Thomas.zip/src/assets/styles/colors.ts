const colors = {
  black: 'rgb(32, 35, 41)',
  themeColor: 'rgb(255, 152, 0)',
  white: '#ffffff',
  green: 'rgb(85, 204, 68)',
  lightGrey: 'rgb(158, 158, 158)',
  mediumGrey: 'rgb(60,62,68)',
}

export default colors;
