import { singleCharacterType } from "../../utils/types/globalTypes";

export type Props = {
  dataSet: singleCharacterType;
};
