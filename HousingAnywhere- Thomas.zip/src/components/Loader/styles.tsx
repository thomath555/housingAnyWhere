// Core
import styled from 'styled-components';

export const LoaderWrapper = styled.div`
    padding: 30px 0;
`