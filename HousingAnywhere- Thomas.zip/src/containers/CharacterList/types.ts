export type Props = {};

export type dataSetType = {
    info: object | any;
    results: Array<object> | any;
};
